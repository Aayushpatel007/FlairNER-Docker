from flask import Flask,jsonify,request,make_response,url_for,redirect
import requests, json

from flair.data import Sentence
from flair.models import SequenceTagger

#GPU OR CPU 
import sys

cpu_or_gpu = int(sys.argv[1])
model_ = "ner-ontonotes"
if cpu_or_gpu == 0:
    model_ = "ner-ontonotes-fast"
else:
    model_ = "ner-ontonotes"

# load the NER tagger
tagger = SequenceTagger.load("ner")

app = Flask(__name__)


@app.route("/healthcheck")
def hello():
    return "Yes, I am ohk. Health check success"

@app.route('/flairner', methods=['POST'])
def sifrank():
    req_data = request.get_json(force=True)
    text = req_data['text']
    sentence = Sentence(text)
    tagger.predict(sentence)
    o = sentence.to_dict(tag_type='ner')
    output = o['entities']
    ORG =[]
    LOC =[]
    PERSON =[]
    ADDITIONAL = []
    for i in range(len(output)):
        if output[i]["type"] == "LOC":
            LOC.append(output[i]["text"])
        elif output[i]["type"] == "PER":
            PERSON.append(output[i]["text"])
        elif output[i]["type"] == "ORG":
            ORG.append(output[i]["text"])
        elif output[i]["type"] == "MISC":
            ADDITIONAL.append(output[i]["text"])

    entities = {
            'ORG': list(set(ORG)),
            "PERSON" : list(set(PERSON)),
            "LOC": list(set(LOC)),
            "ADDITIONAL" : list(set(ADDITIONAL))
        }

    return jsonify(entities)
    
if __name__ == '__main__':
    app.run(host='0.0.0.0',port = 5001,debug=False, use_reloader=True,threaded=True)

